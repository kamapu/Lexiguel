Lexiguel 0.1.0
==============

### New features

* New function `tab4net()` to process data frames for `sankeyNetwork()`.
